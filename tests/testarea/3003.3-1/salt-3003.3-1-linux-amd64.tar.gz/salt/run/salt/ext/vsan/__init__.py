# coding: utf-8 -*-
'''
This directory contains the object model and utils for the vsan VMware SDK
extension.

They are governed under their respective licenses.
'''
